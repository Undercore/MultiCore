﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Multicore
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Multicore))
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.LabelMulticoreversion = New System.Windows.Forms.Label()
        Me.LB_Progress = New System.Windows.Forms.ListBox()
        Me.btn_Clear = New System.Windows.Forms.Button()
        Me.btn_Save = New System.Windows.Forms.Button()
        Me.Threadcount = New System.Windows.Forms.NumericUpDown()
        Me.btn_Scrape = New System.Windows.Forms.Button()
        Me.LB_Grab = New System.Windows.Forms.ListBox()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.btn_Clear2 = New System.Windows.Forms.Button()
        Me.btn_Close = New System.Windows.Forms.Button()
        Me.btn_Save2 = New System.Windows.Forms.Button()
        Me.btn_Parse = New System.Windows.Forms.Button()
        Me.LB_ParsedProxies = New System.Windows.Forms.ListBox()
        Me.TB_Website = New System.Windows.Forms.TextBox()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.btn_Save3 = New System.Windows.Forms.Button()
        Me.btn_Clear3 = New System.Windows.Forms.Button()
        Me.btn_Close3 = New System.Windows.Forms.Button()
        Me.button_Scrape3 = New System.Windows.Forms.Button()
        Me.RTB_UnparsedProxies = New System.Windows.Forms.RichTextBox()
        Me.LB_ParsedProxies3 = New System.Windows.Forms.ListBox()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.CheckingTimeout = New System.Windows.Forms.NumericUpDown()
        Me.Timeout = New System.Windows.Forms.NumericUpDown()
        Me.btn_Export = New System.Windows.Forms.Button()
        Me.btn_ImportProxiesToCheck = New System.Windows.Forms.Button()
        Me.LB_WorkingProxies = New System.Windows.Forms.ListBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TB_Changelog = New System.Windows.Forms.TextBox()
        Me.TB_Update = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.Threadcount, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        CType(Me.CheckingTimeout, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Timeout, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage5.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Controls.Add(Me.TabPage5)
        Me.TabControl1.Location = New System.Drawing.Point(12, 39)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(1441, 692)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.CheckBox1)
        Me.TabPage1.Controls.Add(Me.LabelMulticoreversion)
        Me.TabPage1.Controls.Add(Me.LB_Progress)
        Me.TabPage1.Controls.Add(Me.btn_Clear)
        Me.TabPage1.Controls.Add(Me.btn_Save)
        Me.TabPage1.Controls.Add(Me.Threadcount)
        Me.TabPage1.Controls.Add(Me.btn_Scrape)
        Me.TabPage1.Controls.Add(Me.LB_Grab)
        Me.TabPage1.Location = New System.Drawing.Point(4, 29)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(1433, 659)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "< Gatherer >"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Location = New System.Drawing.Point(738, 624)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(252, 24)
        Me.CheckBox1.TabIndex = 8
        Me.CheckBox1.Text = "Show sites being scraped from"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'LabelMulticoreversion
        '
        Me.LabelMulticoreversion.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.LabelMulticoreversion.AutoSize = True
        Me.LabelMulticoreversion.Location = New System.Drawing.Point(1266, 629)
        Me.LabelMulticoreversion.Name = "LabelMulticoreversion"
        Me.LabelMulticoreversion.Size = New System.Drawing.Size(161, 20)
        Me.LabelMulticoreversion.TabIndex = 7
        Me.LabelMulticoreversion.Text = "Multicore Version: 1.2"
        '
        'LB_Progress
        '
        Me.LB_Progress.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.LB_Progress.FormattingEnabled = True
        Me.LB_Progress.ItemHeight = 20
        Me.LB_Progress.Items.AddRange(New Object() {"Shows the currrent sites being scraped from: "})
        Me.LB_Progress.Location = New System.Drawing.Point(738, 7)
        Me.LB_Progress.Name = "LB_Progress"
        Me.LB_Progress.Size = New System.Drawing.Size(689, 604)
        Me.LB_Progress.TabIndex = 5
        '
        'btn_Clear
        '
        Me.btn_Clear.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.btn_Clear.Location = New System.Drawing.Point(418, 617)
        Me.btn_Clear.Name = "btn_Clear"
        Me.btn_Clear.Size = New System.Drawing.Size(147, 36)
        Me.btn_Clear.TabIndex = 4
        Me.btn_Clear.Text = "Clear"
        Me.btn_Clear.UseVisualStyleBackColor = True
        '
        'btn_Save
        '
        Me.btn_Save.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.btn_Save.Location = New System.Drawing.Point(571, 617)
        Me.btn_Save.Name = "btn_Save"
        Me.btn_Save.Size = New System.Drawing.Size(147, 36)
        Me.btn_Save.TabIndex = 3
        Me.btn_Save.Text = "Save"
        Me.btn_Save.UseVisualStyleBackColor = True
        '
        'Threadcount
        '
        Me.Threadcount.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Threadcount.Location = New System.Drawing.Point(160, 623)
        Me.Threadcount.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.Threadcount.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.Threadcount.Name = "Threadcount"
        Me.Threadcount.Size = New System.Drawing.Size(118, 26)
        Me.Threadcount.TabIndex = 2
        Me.Threadcount.Value = New Decimal(New Integer() {25, 0, 0, 0})
        '
        'btn_Scrape
        '
        Me.btn_Scrape.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btn_Scrape.Location = New System.Drawing.Point(7, 617)
        Me.btn_Scrape.Name = "btn_Scrape"
        Me.btn_Scrape.Size = New System.Drawing.Size(147, 36)
        Me.btn_Scrape.TabIndex = 1
        Me.btn_Scrape.Text = "Gather"
        Me.btn_Scrape.UseVisualStyleBackColor = True
        '
        'LB_Grab
        '
        Me.LB_Grab.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.LB_Grab.FormattingEnabled = True
        Me.LB_Grab.ItemHeight = 20
        Me.LB_Grab.Items.AddRange(New Object() {"[>- Proxies gathered by Multicore -<]", "-                                                       "})
        Me.LB_Grab.Location = New System.Drawing.Point(7, 7)
        Me.LB_Grab.Name = "LB_Grab"
        Me.LB_Grab.Size = New System.Drawing.Size(711, 604)
        Me.LB_Grab.TabIndex = 0
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.btn_Clear2)
        Me.TabPage2.Controls.Add(Me.btn_Close)
        Me.TabPage2.Controls.Add(Me.btn_Save2)
        Me.TabPage2.Controls.Add(Me.btn_Parse)
        Me.TabPage2.Controls.Add(Me.LB_ParsedProxies)
        Me.TabPage2.Controls.Add(Me.TB_Website)
        Me.TabPage2.Location = New System.Drawing.Point(4, 29)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(1433, 659)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "< Parsor >"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'btn_Clear2
        '
        Me.btn_Clear2.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.btn_Clear2.Location = New System.Drawing.Point(1127, 610)
        Me.btn_Clear2.Name = "btn_Clear2"
        Me.btn_Clear2.Size = New System.Drawing.Size(147, 36)
        Me.btn_Clear2.TabIndex = 5
        Me.btn_Clear2.Text = "Clear"
        Me.btn_Clear2.UseVisualStyleBackColor = True
        '
        'btn_Close
        '
        Me.btn_Close.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.btn_Close.Location = New System.Drawing.Point(160, 610)
        Me.btn_Close.Name = "btn_Close"
        Me.btn_Close.Size = New System.Drawing.Size(147, 36)
        Me.btn_Close.TabIndex = 4
        Me.btn_Close.Text = "Exit"
        Me.btn_Close.UseVisualStyleBackColor = True
        '
        'btn_Save2
        '
        Me.btn_Save2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btn_Save2.Location = New System.Drawing.Point(1280, 610)
        Me.btn_Save2.Name = "btn_Save2"
        Me.btn_Save2.Size = New System.Drawing.Size(147, 36)
        Me.btn_Save2.TabIndex = 3
        Me.btn_Save2.Text = "Save"
        Me.btn_Save2.UseVisualStyleBackColor = True
        '
        'btn_Parse
        '
        Me.btn_Parse.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.btn_Parse.Location = New System.Drawing.Point(7, 610)
        Me.btn_Parse.Name = "btn_Parse"
        Me.btn_Parse.Size = New System.Drawing.Size(147, 36)
        Me.btn_Parse.TabIndex = 2
        Me.btn_Parse.Text = "Parse"
        Me.btn_Parse.UseVisualStyleBackColor = True
        '
        'LB_ParsedProxies
        '
        Me.LB_ParsedProxies.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.LB_ParsedProxies.FormattingEnabled = True
        Me.LB_ParsedProxies.ItemHeight = 20
        Me.LB_ParsedProxies.Items.AddRange(New Object() {"[>- Proxies parsed with Multicore -<]", "-"})
        Me.LB_ParsedProxies.Location = New System.Drawing.Point(7, 40)
        Me.LB_ParsedProxies.Name = "LB_ParsedProxies"
        Me.LB_ParsedProxies.Size = New System.Drawing.Size(1420, 564)
        Me.LB_ParsedProxies.TabIndex = 1
        '
        'TB_Website
        '
        Me.TB_Website.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TB_Website.Location = New System.Drawing.Point(7, 7)
        Me.TB_Website.Name = "TB_Website"
        Me.TB_Website.Size = New System.Drawing.Size(1420, 26)
        Me.TB_Website.TabIndex = 0
        Me.TB_Website.Text = "The website you want to parse proxies from: "
        Me.TB_Website.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.btn_Save3)
        Me.TabPage3.Controls.Add(Me.btn_Clear3)
        Me.TabPage3.Controls.Add(Me.btn_Close3)
        Me.TabPage3.Controls.Add(Me.button_Scrape3)
        Me.TabPage3.Controls.Add(Me.RTB_UnparsedProxies)
        Me.TabPage3.Controls.Add(Me.LB_ParsedProxies3)
        Me.TabPage3.Location = New System.Drawing.Point(4, 29)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(1433, 659)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "< Scrape >"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'btn_Save3
        '
        Me.btn_Save3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btn_Save3.Location = New System.Drawing.Point(1271, 616)
        Me.btn_Save3.Name = "btn_Save3"
        Me.btn_Save3.Size = New System.Drawing.Size(147, 36)
        Me.btn_Save3.TabIndex = 5
        Me.btn_Save3.Text = "Save"
        Me.btn_Save3.UseVisualStyleBackColor = True
        '
        'btn_Clear3
        '
        Me.btn_Clear3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btn_Clear3.Location = New System.Drawing.Point(1118, 616)
        Me.btn_Clear3.Name = "btn_Clear3"
        Me.btn_Clear3.Size = New System.Drawing.Size(147, 36)
        Me.btn_Clear3.TabIndex = 4
        Me.btn_Clear3.Text = "Clear"
        Me.btn_Clear3.UseVisualStyleBackColor = True
        '
        'btn_Close3
        '
        Me.btn_Close3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btn_Close3.Location = New System.Drawing.Point(159, 616)
        Me.btn_Close3.Name = "btn_Close3"
        Me.btn_Close3.Size = New System.Drawing.Size(147, 36)
        Me.btn_Close3.TabIndex = 3
        Me.btn_Close3.Text = "Exit"
        Me.btn_Close3.UseVisualStyleBackColor = True
        '
        'button_Scrape3
        '
        Me.button_Scrape3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.button_Scrape3.Location = New System.Drawing.Point(6, 616)
        Me.button_Scrape3.Name = "button_Scrape3"
        Me.button_Scrape3.Size = New System.Drawing.Size(147, 36)
        Me.button_Scrape3.TabIndex = 2
        Me.button_Scrape3.Text = "Scrape"
        Me.button_Scrape3.UseVisualStyleBackColor = True
        '
        'RTB_UnparsedProxies
        '
        Me.RTB_UnparsedProxies.Location = New System.Drawing.Point(6, 3)
        Me.RTB_UnparsedProxies.Name = "RTB_UnparsedProxies"
        Me.RTB_UnparsedProxies.Size = New System.Drawing.Size(708, 607)
        Me.RTB_UnparsedProxies.TabIndex = 1
        Me.RTB_UnparsedProxies.Text = ""
        '
        'LB_ParsedProxies3
        '
        Me.LB_ParsedProxies3.FormattingEnabled = True
        Me.LB_ParsedProxies3.ItemHeight = 20
        Me.LB_ParsedProxies3.Items.AddRange(New Object() {"[>- Proxies scraped with Multicore -<]", "-"})
        Me.LB_ParsedProxies3.Location = New System.Drawing.Point(720, 6)
        Me.LB_ParsedProxies3.Name = "LB_ParsedProxies3"
        Me.LB_ParsedProxies3.Size = New System.Drawing.Size(698, 604)
        Me.LB_ParsedProxies3.TabIndex = 0
        '
        'TabPage4
        '
        Me.TabPage4.Controls.Add(Me.Label4)
        Me.TabPage4.Controls.Add(Me.CheckingTimeout)
        Me.TabPage4.Controls.Add(Me.Timeout)
        Me.TabPage4.Controls.Add(Me.btn_Export)
        Me.TabPage4.Controls.Add(Me.btn_ImportProxiesToCheck)
        Me.TabPage4.Controls.Add(Me.LB_WorkingProxies)
        Me.TabPage4.Controls.Add(Me.Label3)
        Me.TabPage4.Location = New System.Drawing.Point(4, 29)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(1433, 659)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "< Checker >"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'CheckingTimeout
        '
        Me.CheckingTimeout.Location = New System.Drawing.Point(1150, 622)
        Me.CheckingTimeout.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.CheckingTimeout.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.CheckingTimeout.Name = "CheckingTimeout"
        Me.CheckingTimeout.Size = New System.Drawing.Size(120, 26)
        Me.CheckingTimeout.TabIndex = 5
        Me.CheckingTimeout.Value = New Decimal(New Integer() {10, 0, 0, 0})
        '
        'Timeout
        '
        Me.Timeout.Location = New System.Drawing.Point(164, 623)
        Me.Timeout.Maximum = New Decimal(New Integer() {10000000, 0, 0, 0})
        Me.Timeout.Minimum = New Decimal(New Integer() {500, 0, 0, 0})
        Me.Timeout.Name = "Timeout"
        Me.Timeout.Size = New System.Drawing.Size(120, 26)
        Me.Timeout.TabIndex = 4
        Me.Timeout.Value = New Decimal(New Integer() {5000, 0, 0, 0})
        '
        'btn_Export
        '
        Me.btn_Export.Location = New System.Drawing.Point(1276, 616)
        Me.btn_Export.Name = "btn_Export"
        Me.btn_Export.Size = New System.Drawing.Size(151, 36)
        Me.btn_Export.TabIndex = 3
        Me.btn_Export.Text = "Export"
        Me.btn_Export.UseVisualStyleBackColor = True
        '
        'btn_ImportProxiesToCheck
        '
        Me.btn_ImportProxiesToCheck.Location = New System.Drawing.Point(7, 617)
        Me.btn_ImportProxiesToCheck.Name = "btn_ImportProxiesToCheck"
        Me.btn_ImportProxiesToCheck.Size = New System.Drawing.Size(151, 36)
        Me.btn_ImportProxiesToCheck.TabIndex = 2
        Me.btn_ImportProxiesToCheck.Text = "Check"
        Me.btn_ImportProxiesToCheck.UseVisualStyleBackColor = True
        '
        'LB_WorkingProxies
        '
        Me.LB_WorkingProxies.FormattingEnabled = True
        Me.LB_WorkingProxies.ItemHeight = 20
        Me.LB_WorkingProxies.Location = New System.Drawing.Point(7, 7)
        Me.LB_WorkingProxies.Name = "LB_WorkingProxies"
        Me.LB_WorkingProxies.Size = New System.Drawing.Size(1420, 604)
        Me.LB_WorkingProxies.TabIndex = 1
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(1073, 624)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(71, 20)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "Threads:"
        '
        'TabPage5
        '
        Me.TabPage5.Controls.Add(Me.Label2)
        Me.TabPage5.Controls.Add(Me.Label1)
        Me.TabPage5.Controls.Add(Me.TB_Changelog)
        Me.TabPage5.Controls.Add(Me.TB_Update)
        Me.TabPage5.Location = New System.Drawing.Point(4, 29)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Size = New System.Drawing.Size(1433, 659)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "< Updates >"
        Me.TabPage5.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(1344, 613)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(86, 20)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Changelog"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(3, 613)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(62, 20)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Update"
        '
        'TB_Changelog
        '
        Me.TB_Changelog.Location = New System.Drawing.Point(709, 4)
        Me.TB_Changelog.Multiline = True
        Me.TB_Changelog.Name = "TB_Changelog"
        Me.TB_Changelog.Size = New System.Drawing.Size(721, 606)
        Me.TB_Changelog.TabIndex = 1
        '
        'TB_Update
        '
        Me.TB_Update.Location = New System.Drawing.Point(3, 4)
        Me.TB_Update.Multiline = True
        Me.TB_Update.Name = "TB_Update"
        Me.TB_Update.Size = New System.Drawing.Size(700, 606)
        Me.TB_Update.TabIndex = 0
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(290, 625)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(74, 20)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Time-Out"
        '
        'Multicore
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1465, 743)
        Me.Controls.Add(Me.TabControl1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Multicore"
        Me.Text = "Multicore"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        CType(Me.Threadcount, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage4.ResumeLayout(False)
        Me.TabPage4.PerformLayout()
        CType(Me.CheckingTimeout, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Timeout, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage5.ResumeLayout(False)
        Me.TabPage5.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents btn_Clear As Button
    Friend WithEvents btn_Save As Button
    Friend WithEvents Threadcount As NumericUpDown
    Friend WithEvents btn_Scrape As Button
    Friend WithEvents LB_Grab As ListBox
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents TabPage4 As TabPage
    Friend WithEvents LB_Progress As ListBox
    Friend WithEvents LabelMulticoreversion As Label
    Friend WithEvents btn_Save2 As Button
    Friend WithEvents btn_Parse As Button
    Friend WithEvents LB_ParsedProxies As ListBox
    Friend WithEvents TB_Website As TextBox
    Friend WithEvents btn_Clear2 As Button
    Friend WithEvents btn_Close As Button
    Friend WithEvents btn_Save3 As Button
    Friend WithEvents btn_Clear3 As Button
    Friend WithEvents btn_Close3 As Button
    Friend WithEvents button_Scrape3 As Button
    Friend WithEvents LB_ParsedProxies3 As ListBox
    Friend WithEvents TabPage5 As TabPage
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents TB_Changelog As TextBox
    Friend WithEvents TB_Update As TextBox
    Friend WithEvents RTB_UnparsedProxies As RichTextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents CheckBox1 As CheckBox
    Friend WithEvents btn_ImportProxiesToCheck As Button
    Friend WithEvents LB_WorkingProxies As ListBox
    Friend WithEvents btn_Export As Button
    Friend WithEvents Timeout As NumericUpDown
    Friend WithEvents CheckingTimeout As NumericUpDown
    Friend WithEvents Label4 As Label
End Class
